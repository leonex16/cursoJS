# Grid CSS

En esta serie te enseño todo lo que necesitas saber sobre Grid CSS para maquetar sitios y aplicaciones web.

- Videos del Curso: https://www.youtube.com/playlist?list=PLvq-jIkSeTUY628cyd9LVbXSXi2xG9mUl
- Códigos finales del Curso: https://github.com/jonmircha/youtube-grid
- Nota sobre Grid CSS en mi blog personal https://jonmircha.com/grid

Mis Redes Sociales:

- 🔔 Suscríbete al canal https://youtube.com/jonmircha?sub_confirmation=1 🤓
- 👉 Visita mi sitio web https://jonmircha.com/ 💻
- 🌮 ¿Me invítas un taco? https://www.paypal.me/jonmircha
- 📫 Suscríbete a mi lista de correo https://tinyletter.com/jonmircha/
